import 'package:flutter/material.dart';

const primaryColor = Color(0xFF2697FF);
const secondaryColor = Color(0xFF161616);
const bgColor = Color(0xFF000000);

const defaultPadding = 16.0;
